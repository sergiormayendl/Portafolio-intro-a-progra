﻿using System;

class cafetera
{
    public string Codigo { get; private set; }
    public int Capacidad { get; private set; }
    public int Disponibles { get; private set; }
    public int Tazas { get; private set; }


    public void HacerCafe()
    {
        Disponibles = Capacidad;
        Tazas = 0;
    }

    public bool ServirCafe(int tazas)
    {
        if (tazas <= Disponibles)
        {
            Disponibles = Disponibles - tazas;
            Tazas = Tazas + tazas;
            return true;
        }
        else
        {
            Console.WriteLine("no hay tazas disponibles...");
            return false;
        }
    }
    public double Porcentaje()
    {
        return (double)Disponibles / Capacidad * 100;
    }

    public void Resultados()
    {
        Console.WriteLine("Código: " + Codigo);
        Console.WriteLine("Capacidad: " + Capacidad);
        Console.WriteLine("Porcentaje de disponibles: " + Porcentaje());
        Console.WriteLine("Tazas: " + Tazas);
    }

    //Constructor
    public cafetera(string elCodigo, int laCapacidad)
    {
        Codigo = elCodigo;
        Capacidad = laCapacidad;
        Disponibles = 0;
    }

    public static void Main()
    {
        Console.WriteLine("Ingrese capacidad de la cafetera");
        int cap = Convert.ToInt32(Console.ReadLine());
        string op = "s";

        cafetera cafe = new cafetera("200", cap);

        cafe.HacerCafe();

        do
        {
            Console.WriteLine("Cuántas tazas quiere servir? ");
            int tz = Convert.ToInt32(Console.ReadLine());
            cafe.ServirCafe(tz);
            cafe.Resultados();

            Console.WriteLine("Desea ingresar más tazas? s/n");
            op = Console.ReadLine().ToLower();
        } while (op == "s");
    }
}