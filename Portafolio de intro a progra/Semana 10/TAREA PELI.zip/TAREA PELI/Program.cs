﻿using System;


public class Pelicula
{
    private string nombre, genero, valoracion = "";
    private double calificacion = 0, duracion;
    private int anio;

    public int Anio { get { return anio; } }
    public string Nombre { get { return nombre; } }
    public string Genero { get { return genero; } }
    public string Valoracion { get { return valoracion; } }
    public double Calificacion { get { return calificacion; } }
    public double Duracion { get { return duracion; } }

    public Pelicula(string laValoracion, string elGenero)
    {
        nombre = "Película";
        duracion = 4;
        genero = elGenero;
        anio = 2010;
        valoracion = laValoracion;
    }

    

    public string mostrarInformacion()
    {
        return $"El nombre de la película es: {Nombre}.\nLa duración es: {Duracion}.\nEl género es: {Genero}.\nEl año es: {Anio}.\nLa calificación es de: {Calificacion}.\nLa valoracion es de: {Valoracion}";
    }

    public bool esPeliculaEpica()
    {
        if (Duracion >= 180)
        {
            return true;
        } else
        {
            return false;
        }
    }
    public string laCalificacion()
    {
        if (Calificacion >= 0 && Calificacion <= 2)
        {
            valoracion = "Muy mala";
            return valoracion;
        }
        else if (Calificacion > 2 && Calificacion <= 5)
        {
            valoracion = "Mala";
            return valoracion;
        }
        else if (Calificacion > 5 && Calificacion <= 7)
        {
            valoracion = "Regular";
            return valoracion;
        }
        else if (Calificacion > 7 && Calificacion <= 8)
        {
            valoracion = "Buena";
            return valoracion;
        }
        else if (Calificacion > 8 && Calificacion <= 10)
        {
            valoracion = "Excelenete";
            return valoracion;
        } else
        {
            valoracion = "";
            return valoracion;
        }
    }
    public bool esSimilar(Pelicula otraPelicula)
    {
        if (this.genero == otraPelicula.genero && this.valoracion == otraPelicula.valoracion)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public static void Main()
    {
        Pelicula pelicula1 = new Pelicula("EXCELENTE", "DRAMA");
        pelicula1.nombre = "Gandhi";
        pelicula1.duracion = 191;
        pelicula1.anio = 1982;
        pelicula1.calificacion = 8.1;

        Pelicula pelicula2 = new Pelicula("BUENA", "ACCION");
        pelicula2.nombre = "Thor";
        pelicula2.duracion = 115;
        pelicula2.anio = 2011;
        pelicula2.calificacion = 7.0;

        Console.WriteLine(pelicula1.mostrarInformacion());
        Console.WriteLine("Es película épica? " + pelicula1.esPeliculaEpica()+ "\n");
        Console.WriteLine(pelicula2.mostrarInformacion());
        Console.WriteLine("Es película épica? " + pelicula2.esPeliculaEpica() + "\n");

        bool similares = pelicula1.esSimilar(pelicula2);

        Console.WriteLine($"¿Las películas son similares?: {similares}");

        Console.ReadKey();
    }
}