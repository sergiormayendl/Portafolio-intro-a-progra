using System;

class Program
{
    static void Main()
    {
        double ahorroMes = 0;
        double ahorroAño = 0;
        double deposito = 0;

        for (int i = 1; i <= 12; i++)
        {
            Console.Write("Ingrese el depósito del mes " + i + ": $");
            deposito = Convert.ToDouble(Console.ReadLine());
            ahorroMes += deposito;
            ahorroAño += deposito;

            Console.WriteLine("El ahorro acumulado hasta el mes " + i + " es de: $" + ahorroMes);
        }

        Console.WriteLine("El ahorro anual es de: $" + ahorroAño);
        Console.ReadKey();
    }
}