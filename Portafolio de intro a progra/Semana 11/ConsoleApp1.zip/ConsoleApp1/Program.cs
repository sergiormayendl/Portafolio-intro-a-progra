﻿using System;

public class Libro
{
    private string nombre, mensaje, estado;
    private int codigo, cantidad, pagina, contador, pagleer;
    private double porcentaje;

    public int Codigo { get { return codigo; } }
    public string Nombre { get { return nombre; } }
    public string Mensaje { get { return mensaje; } }
    public int Cantidad { get { return cantidad; } }
    public int Pagina { get { return pagina; } }
    public double Porcentaje { get { return porcentaje; } }

    public Libro(string nombre, int codigo, int cantidad)
    {
        this.nombre = nombre;
        this.codigo = codigo;
        this.cantidad = cantidad;
    }

    public string leer(int cantPag)
    {
        pagleer = cantPag;
        
        if (cantPag > cantidad)
        {
            mensaje = "No puede leer más páginas";
        } else
        {
            contador = pagleer;
        }
        return mensaje;
    }

    public double obtenerPorcentaje()
    {
        porcentaje = (contador * 100) / cantidad;
        return porcentaje;
    }

    public int pagActual()
    {
        return pagleer;
    }

    public string mostrarLibro()
    {
        return $"El codigo es: {codigo}.\nEl nombre es: {nombre}.\nLa cantidad de páginas es: {cantidad}.\nEl porcentaje de lectura es: {porcentaje}.\nLa cantidad de paginas leídas es: {contador}.\n";
    }

    public string estadoLibro()
    {
        if (contador == cantidad)
        {
            estado = "Leído";
        } else if (contador < cantidad)
        {
            estado = "En proceso";
        } else
        {
            estado = "No leído";
        }
        return estado;
    }

    public static void Main()
    {
        Libro libro1 = new Libro("Libro 1", 101, 100);
        libro1.leer(10);
        Console.WriteLine(libro1.mostrarLibro());
        Console.ReadKey();
    }
}