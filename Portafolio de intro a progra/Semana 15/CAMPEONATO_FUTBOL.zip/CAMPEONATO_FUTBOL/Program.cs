﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAMPEONATO_FUTBOL
{
    internal class Program
    {
        static void Main(string[] args)
        {
    
            Random random = new Random();
            Console.WriteLine("\n¿Cuántos equipos desea agregar?");
            int cant = 0;
            cant = Convert.ToInt32(Console.ReadLine());
            int cont = 0;


            int[,] mat1 = new int[cant, cant + 1];
            string[] nombres = new string[cant];
            try
            {
                for (int i = 0; i < cant; i++)
                {
                    Console.WriteLine("\nIngrese el nombre del equipo: ");
                    string nuevoNombre = Console.ReadLine();

                    while (nombres.Contains(nuevoNombre))
                    {
                        Console.WriteLine("El nombre ingresado ya existe. Ingrese un nombre diferente: ");
                        nuevoNombre = Console.ReadLine();
                    }

                    nombres[i] = nuevoNombre;
                }

                Console.Clear();

                Console.WriteLine("TABLA DE ESTADÍSTICAS");
                int[,] estadisticas = new int[cant, 7];
                for (int i = 0; i < cant; i++)
                {
                    estadisticas[i, 0] = random.Next(1, 15);
                    estadisticas[i, 1] = random.Next(1, 15);
                    estadisticas[i, 2] = random.Next(1, 15);
                    estadisticas[i, 3] = random.Next(1, 15);
                    estadisticas[i, 4] = random.Next(1, 15);
                    estadisticas[i, 5] = random.Next(1, 15);
                    estadisticas[i, 6] = random.Next(1, 15);

                    Console.WriteLine("");
                    Console.WriteLine(nombres[i] + "\t Jugados: " + estadisticas[i, 1] + "\t Ganados: " + estadisticas[i, 2] + "\t Empatados: " + estadisticas[i, 3] + "\t Perdidos: " + estadisticas[i, 4] + "\t Goles a favor: " + estadisticas[i, 5] + "\t Goles en contra: " + estadisticas[i, 6]);
                }
            }
            catch
            {
                Console.WriteLine("Ingrese números que NO sean negativos.");
            }
            Console.ReadKey();
        }
    }
}
